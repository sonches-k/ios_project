//
//  AuthService.swift
//  InvestTrack
//
//  Created by Соня on 14.03.2024.
//


import Foundation
import Combine

class AuthService {
    func authenticate(email: String, password: String) -> AnyPublisher<AuthResponse, Error> {
        let url = URL(string: "http://investtrack.nasavasa.ru/oauth2/auth")!
        let body = ["email": email, "password": password]
        let jsonData = try! JSONSerialization.data(withJSONObject: body)
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        
        return URLSession.shared.dataTaskPublisher(for: request)
            .tryMap { data, response in
                // данные из json
                if let httpResponse = response as? HTTPURLResponse {
                    print("HTTP Status Code: \(httpResponse.statusCode)")
                }
                let responseString = String(data: data, encoding: .utf8)
                print("JSON Response: \(responseString ?? "Failed to decode response data")")
                do {
                    let decodedData = try JSONDecoder().decode(AuthResponse.self, from: data)
                    return decodedData
                } catch {
                    print("Decoding error: \(error)")
                    throw error
                }
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}
