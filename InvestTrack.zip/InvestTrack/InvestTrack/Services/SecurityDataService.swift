//
//  SecurityDataService.swift
//  InvestTrack
//
//  Created by Соня on 09.03.2024.
//

import Foundation
import Combine

class SecurityDataService {
    
    @Published var allSecurities: [SecurityModel] = []
    
    var securitySubscription: AnyCancellable?
    let tokenManager: KeychainTokenManager // свойство для управления токенами
    
    init(tokenManager: KeychainTokenManager) { // берем KeychainTokenManager в качестве параметра
        self.tokenManager = tokenManager
        
        getSecurities()
    }
    
    private func getSecurities() {
        guard let url = URL(string: "http://investtrack.nasavasa.ru/securities?access_token=\(tokenManager.getToken(forKey: "access_token") ?? "")") else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        if let token = tokenManager.getToken(forKey: "access_token") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        } else {
            print("Token not found")
            return
        }
        
        securitySubscription = URLSession.shared.dataTaskPublisher(for: request)
            .tryMap { output in
                guard let response = output.response as? HTTPURLResponse,
                      (200 ..< 300) ~= response.statusCode else {
                    throw URLError(.badServerResponse)
                }
                return output.data
            }
            .decode(type: SecuritiesResponse.self, decoder: JSONDecoder())
            .map { $0.data.securities }
            .replaceError(with: [])
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
                switch completion {
                case .finished:
                    print("Received securities successfully")
                case .failure(let error):
                    print("Failed to receive securities: \(error.localizedDescription)")
                }
            }, receiveValue: { [weak self] securities in
                print("Received \(securities.count) securities")
                self?.allSecurities = securities
            })
    }
}

struct SecuritiesResponse: Codable {
    let data: SecuritiesData
}

struct SecuritiesData: Codable {
    let securities: [SecurityModel]
}


