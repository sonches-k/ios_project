//
//  XmarkButton.swift
//  InvestTrack
//
//  Created by Соня on 15.03.2024.
//

import SwiftUI

struct XmarkButton: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        Button(action: {
            //            presentationMode.wrappedValue.dismiss()
            //            showSettingsView.toggle()
        }, label : {
            Image(systemName: "xmark")
                .font(.headline)
        })
    }
}

struct XmarkButton_Previews: PreviewProvider {
    static var previews: some View {
        XmarkButton()
    }
}
