//
//  OnboardingView.swift
//  InvestTrack
//
//  Created by Соня on 15.03.2024.
//

import SwiftUI

struct OnboardingView: View {
    let title: String
    let symbol: String
    let description: String
    let gradient: Gradient
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: gradient, startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea(.all)
            
            VStack {
                Image(systemName: symbol)
                    .font(.system(size: 80))
                    .padding()
                Text(title)
                    .font(.system(size: 60))
                    .fontWeight(.bold)
                Text(description)
                    .font(.system(size: 20))
                    .multilineTextAlignment(.center)
                    .italic()
                    .fontWeight(.semibold)
                    .padding()
            }
            .foregroundColor(.white)
        }
    }
}

struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingView(title: "Hello!", symbol: "sun.max.fill", description: "Are you new to the world of investing?", gradient: Gradient(colors: [Color.blue, Color.purple]))
    }
}
