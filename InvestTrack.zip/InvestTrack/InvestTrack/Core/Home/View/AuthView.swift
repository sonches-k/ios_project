//
//  AuthView.swift
//  InvestTrack
//
//  Created by Соня on 14.03.2024.
//

import SwiftUI

struct AuthView: View {
    @ObservedObject var viewModel: AuthViewModel
    
    @State private var email = ""
    @State private var password = ""
    @State private var showAlert = false
    
    var body: some View {
        ZStack {
            // background layer
            Color.theme.background
                .ignoresSafeArea()
            
            VStack(spacing: 10) {
                Spacer()
                TextField("Email", text: $email)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .font(.title)
                    .padding()
                    .frame(minHeight: 10)
                    .frame(minWidth: 10, maxWidth: .infinity)
                    .autocapitalization(.none)
                    .foregroundColor(Color.theme.accent)
                
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .font(.title)
                    .padding()
                    .frame(height: 60)
                    .frame(minWidth: 10, maxWidth: .infinity)
                    .foregroundColor(Color.theme.accent)
                
                Spacer()
                Button(action: {
                    guard !email.isEmpty, !password.isEmpty else {
                        viewModel.errorMessage = "Email and password are required"
                        viewModel.showAlert = true
                        return
                    }
                    
                    viewModel.authenticate(email: email, password: password)
                }) {
                    Text("Login")
                        .frame(minWidth: 0, maxWidth: 200)
                        .padding()
                        .background(Color.theme.accent)
                        .foregroundColor(.white)
                        .cornerRadius(50)
                }
                .disabled(viewModel.isLoading)
                
                Spacer()
            }
            .padding()
            .alert(isPresented: $viewModel.showAlert) {
                Alert(title: Text("Error"), message: Text(viewModel.errorMessage ?? ""), dismissButton: .default(Text("OK")))
            }
            .fullScreenCover(isPresented: $viewModel.isAuthenticated) {
                NavigationView {
                    HomeView()
                        .navigationBarHidden(true)
                }
            }
        }
    }
}


//struct AuthView_Previews: PreviewProvider {
//    static var previews: some View {
//        let keychainTokenManager = KeychainTokenManager(service: "http://investtrack.nasavasa.ru/oauth2/auth")
//        let authManager = AuthManager(authService: AuthService(), tokenManager: keychainTokenManager)
//        let authViewModel = AuthViewModel(authManager: authManager, tokenManager: keychainTokenManager)
//        
//        return AuthView(viewModel: authViewModel)
//    }
//}
