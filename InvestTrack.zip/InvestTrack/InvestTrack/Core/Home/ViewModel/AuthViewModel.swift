//
//  AuthViewModel.swift
//  InvestTrack
//
//  Created by Соня on 14.03.2024.
//

import Foundation
import Combine

class AuthViewModel: ObservableObject {
    private let authManager: AuthManager
    private var cancellables = Set<AnyCancellable>()
    private let tokenManager: KeychainTokenManager
    
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showAlert = false
    
    @Published var isAuthenticated = false
    
    init(authManager: AuthManager, tokenManager: KeychainTokenManager) {
        self.authManager = authManager
        self.tokenManager = tokenManager
    }
    
    func authenticate(email: String, password: String) {
        isLoading = true
        
        authManager.authenticate(email: email, password: password)
            .sink { completion in
                self.isLoading = false
                switch completion {
                case .finished:
                    // Успешная аутентификация
                    self.isAuthenticated = true
                    self.errorMessage = nil // Очистка сообщения об ошибке
                    self.tokenManager.printSavedTokens()
                case .failure(let error):
                    // Ошибка аутентификации,обрабатываем
                    self.isAuthenticated = false
                    self.errorMessage = "Incorrect credentials entered. \nTry again."
                    self.showAlert = true
                    print(error)
                }
            } receiveValue: { response in
                // Обработка ответа
            }
            .store(in: &cancellables)
    }
}
