//
//  HomeViewModel.swift
//  InvestTrack
//
//  Created by Соня on 08.03.2024.
//

import Foundation
import Combine

class HomeViewModel: ObservableObject {
    
    @Published var allSecurities: [SecurityModel] = []
    @Published var portfolioSecurities: [SecurityModel] = []
    
    private let dataService: SecurityDataService
    
    private var cancellables = Set<AnyCancellable>()
    
    init(tokenManager: KeychainTokenManager) {
        self.dataService = SecurityDataService(tokenManager: tokenManager)
        addSubscribers()
    }
    
    func addSubscribers() {
        
        dataService.$allSecurities
            .sink { [weak self] (returnedSecurities) in
                self?.allSecurities = returnedSecurities
            }
            .store(in: &cancellables)
    }
}
