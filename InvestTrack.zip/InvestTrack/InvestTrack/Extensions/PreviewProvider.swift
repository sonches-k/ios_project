//
//  PreviewProvider.swift
//  InvestTrack
//
//  Created by Соня on 07.03.2024.
//

import Foundation
import SwiftUI

extension PreviewProvider {
    
    static var dev: DeveloperPreview {
        return DeveloperPreview.instance
    }
    
}
class DeveloperPreview {
    
    static let instance = DeveloperPreview()
    
    let homeVM: HomeViewModel
    
    init() {
        let tokenManager = KeychainTokenManager(service: "com.investtrack.token")
        self.homeVM = HomeViewModel(tokenManager: tokenManager)
    }
    
    let security = SecurityModel(
        securityId: "SBER",
        boardId: "TQBR",
        name: "Sberbank",
        currentPrice: 300.9,
        priceChange24H: 1.11,
        priceChangePercentage24H: 0.37,
        history: nil,
        analytics: Analytics(
            maxPrice: 300.9,
            minPrice: 300.9,
            maxValue: 300.9,
            minValue: 300.9,
            averagePrice: 300.9,
            averageValue: 300.9
        ),
        currentHoldings: 0
    )
}


