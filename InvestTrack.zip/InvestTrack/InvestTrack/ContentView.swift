//
//  ContentView.swift
//  InvestTrack
//
//  Created by Соня on 15.02.2024.
//

import SwiftUI

struct ContentView: View {
    @State private var isAuthViewPresented = false
    @State private var currentPage = 0
    
    var body: some View {
        VStack {
            TabView(selection: $currentPage) {
                OnboardingView(title: "Welcome!", symbol: "sun.max.fill", description: "Are you new to the world of investing?", gradient: Gradient(colors: [Color.blue, Color.purple]))
                    .tag(0)
                OnboardingView(title: "Explore", symbol: "creditcard.fill", description: "Discover new investment opportunities", gradient: Gradient(colors: [Color.green, Color.yellow]))
                    .tag(1)
                OnboardingView(title: "Invest", symbol: "dollarsign.square.fill", description: "Start building your investment portfolio", gradient: Gradient(colors: [Color.orange, Color.red]))
                    .tag(2)
            }
            .ignoresSafeArea()
            .tabViewStyle(.page)
            .overlay(
                VStack {
                    Spacer()
                    if currentPage == 2 {
                        Button("Get Started") {
                            isAuthViewPresented.toggle()
                        }
                        .padding()
                        .font(.title3)
                        .background(Color.white.opacity(0.7))
                        .foregroundColor(.orange)
                        .cornerRadius(40)
                        .padding()
                        .sheet(isPresented: $isAuthViewPresented) {
                            NavigationView {
                                AuthView(viewModel: AuthViewModel(
                                    authManager: AuthManager(authService: AuthService(), tokenManager: KeychainTokenManager(service: "com.investtrack.token")),
                                    tokenManager: KeychainTokenManager(service: "com.investtrack.token")
                                ))
                            }
                        }
                    }
                }
            )
        }
        .ignoresSafeArea()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
