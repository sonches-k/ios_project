//
//  AuthManager.swift
//  InvestTrack
//
//  Created by Соня on 14.03.2024.
//

import Foundation
import Combine

class AuthManager {
    let authService: AuthService
    let tokenManager: KeychainTokenManager
    
    init(authService: AuthService, tokenManager: KeychainTokenManager) {
        self.authService = authService
        self.tokenManager = tokenManager
    }
    
    func authenticate(email: String, password: String) -> AnyPublisher<AuthResponse, Error> {
        return authService.authenticate(email: email, password: password)
            .flatMap { response in
                self.tokenManager.saveTokens(accessToken: response.data.accessToken , refreshToken: response.data.refreshToken )
                return Just(response).setFailureType(to: Error.self).eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()
    }
}






