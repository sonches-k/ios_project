//
//  KeychainTokenManager.swift
//  InvestTrack
//
//  Created by Соня on 14.03.2024.
//

import Foundation
import Security

struct KeychainTokenManager {
    
    private let service: String
    private let accessTokenKey = "access_token"
    private let refreshTokenKey = "refresh_token"
    
    init(service: String) {
        self.service = service
    }
    
    func saveTokens(accessToken: String, refreshToken: String) {
        saveToken(accessToken, forKey: accessTokenKey)
        saveToken(refreshToken, forKey: refreshTokenKey)
        print("Tokens saved successfully.")
    }
    
    func getTokens() -> (accessToken: String?, refreshToken: String?) {
        let accessToken = getToken(forKey: accessTokenKey)
        let refreshToken = getToken(forKey: refreshTokenKey)
        if accessToken != nil && refreshToken != nil {
               print("Tokens retrieved successfully.")
           } else {
               print("Failed to retrieve tokens.")
           }
        return (accessToken, refreshToken)
    }
    
    func clearTokens() {
        deleteToken(forKey: accessTokenKey)
        deleteToken(forKey: refreshTokenKey)
    }
    
    
    private func saveToken(_ token: String, forKey key: String) {
        guard let data = token.data(using: .utf8) else { return }
        
        var query = defaultQuery()
        query[kSecAttrAccount as String] = key
        query[kSecValueData as String] = data
        
        SecItemDelete(query as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }
    
    public func getToken(forKey key: String) -> String? {
        var query = defaultQuery()
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        query[kSecReturnAttributes as String] = kCFBooleanTrue
        query[kSecReturnData as String] = kCFBooleanTrue
        query[kSecAttrAccount as String] = key
        
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let item = result as? [String: Any], let data = item[kSecValueData as String] as? Data else {
            return nil
        }
        
        return String(data: data, encoding: .utf8)
    }
    
    private func deleteToken(forKey key: String) {
        var query = defaultQuery()
        query[kSecAttrAccount as String] = key
        SecItemDelete(query as CFDictionary)
    }
    
    private func defaultQuery() -> [String: Any] {
        return [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlocked
        ]
    }
    func printSavedTokens() {
           let tokens = getTokens()
           if let accessToken = tokens.accessToken, let refreshToken = tokens.refreshToken {
               print("Access Token: \(accessToken)")
               print("Refresh Token: \(refreshToken)")
           } else {
               print("No tokens saved.")
           }
       }
}
