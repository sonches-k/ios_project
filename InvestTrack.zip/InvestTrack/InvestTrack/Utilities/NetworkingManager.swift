//
//  NetworkingManager.swift
//  InvestTrack
//
//  Created by Соня on 09.03.2024.
//

import Foundation
import Combine

class NetworkingManager {
    
    enum NetworkingError: LocalizedError {
        case badURLResponse(url: URL)
        case unknown
        
        var errorDescription: String? {
            switch self {
            case .badURLResponse(url: let url): return "Bad response from URL. \(url)"
            case .unknown: return "Unknown error occurred"
            }
        }
    }
    
    static func downloadSecurities(token: String) -> AnyPublisher<Data, Error> {
        guard let url = URL(string: "http://investtrack.nasavasa.ru/securities?access_token=\(token)") else {
            fatalError("Invalid URL")
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        return download(request: request)
    }
    
    static func download(request: URLRequest) -> AnyPublisher<Data, Error> {
        return URLSession.shared.dataTaskPublisher(for: request)
            .tryMap { output in
                guard let response = output.response as? HTTPURLResponse,
                      (200 ..< 300) ~= response.statusCode else {
                    throw NetworkingError.badURLResponse(url: request.url!)
                }
                return output.data
            }
            .mapError { error in
                NetworkingError.unknown
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}
