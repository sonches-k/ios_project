//
//  File.swift
//  InvestTrack
//
//  Created by Соня on 07.03.2024.
//

import Foundation

struct SecurityModel: Codable {
    let securityId: String
    let boardId: String
    let name: String
    let currentPrice: Double
    let priceChange24H: Double
    let priceChangePercentage24H: Double
    let history: History?
    let analytics: Analytics?
    let currentHoldings: Double?
    
    enum CodingKeys: String, CodingKey {
        case securityId = "security_id"
        case boardId = "board_id"
        case name
        case currentPrice = "current_price"
        case priceChange24H = "price_change_24h"
        case priceChangePercentage24H = "price_change_percentage_24h"
        case history
        case analytics
        case currentHoldings
    }
}

extension SecurityModel: Identifiable {
    var id: String { securityId }
}

extension SecurityModel {
    func updateHoldings(amount: Double) -> SecurityModel {
        return SecurityModel(securityId: securityId, boardId: boardId, name: name, currentPrice: currentPrice, priceChange24H: priceChange24H, priceChangePercentage24H: priceChangePercentage24H, history: history, analytics: analytics, currentHoldings: amount)
    }
    
    var currentHoldingsValue: Double {
        return (currentHoldings ?? 0) * (currentPrice)
    }
}

struct History: Codable {
    let date: Date
    let openPrice, lowPrice, highPrice, closePrice, value: Double
    
    enum CodingKeys: String, CodingKey {
        case date
        case openPrice = "open_price"
        case lowPrice = "low_price"
        case highPrice = "high_price"
        case closePrice = "close_price"
        case value
    }
}


struct Analytics: Codable {
    let maxPrice, minPrice, maxValue, minValue, averagePrice, averageValue: Double
    
    enum CodingKeys: String, CodingKey {
        case maxPrice = "max_price"
        case minPrice = "min_price"
        case maxValue = "max_value"
        case minValue = "min_value"
        case averagePrice = "average_price"
        case averageValue = "average_value"
    }
}
