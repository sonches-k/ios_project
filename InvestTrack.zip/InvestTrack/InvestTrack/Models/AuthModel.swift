//
//  AuthModel.swift
//  InvestTrack
//
//  Created by Соня on 14.03.2024.
//

import Foundation

struct AuthResponse: Codable {
    var data: DataClass
    var description: String
}

struct DataClass: Codable {
    var userID: Int
    var accessToken, refreshToken: String
    
    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case accessToken = "access_token"
        case refreshToken = "refresh_token"
    }
}
