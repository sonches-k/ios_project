//
//  ErrorResponseModel.swift
//  InvestTrack
//
//  Created by Соня on 15.03.2024.
//

import Foundation

struct ErrorResponse: Codable {
    let errorCode: Int
    let description: String
    
    enum CodingKeys: String, CodingKey {
        case errorCode = "error_code"
        case description
    }
}
