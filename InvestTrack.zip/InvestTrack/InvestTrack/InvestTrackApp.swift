//
//  InvestTrackApp.swift
//  InvestTrack
//
//  Created by Соня on 15.02.2024.
//



import SwiftUI

@main
struct InvestTrackApp: App {
    
    @StateObject private var authViewModel = AuthViewModel(
        authManager: AuthManager(authService: AuthService(), tokenManager: KeychainTokenManager(service: "com.investtrack.token")),
        tokenManager: KeychainTokenManager(service: "com.investtrack.token")
    )
    
    // Передаем tokenManager в инициализатор HomeViewModel
    @StateObject private var vm = HomeViewModel(tokenManager: KeychainTokenManager(service: "com.investtrack.token"))
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
//                AuthView(viewModel: authViewModel)
//                    .navigationBarHidden(true)
                HomeView()
            }
            .environmentObject(vm)
        }
    }
}

